## $5 Tech Unlocked 2021!
[Buy and download this Video for only $5 on PacktPub.com](https://www.packtpub.com/product/mastering-clean-code-in-javascript-video/9781788999588)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Mastering-Clean-Code-in-JavaScript
Mastering Clean Code in JavaScript [V], published by Packt
